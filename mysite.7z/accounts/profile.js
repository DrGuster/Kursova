document.getElementById('edit_button').addEventListener('click', function() {
    const form = document.querySelector('.profile-form');
    form.classList.toggle('hidden');  // Toggle hidden class on click
  });